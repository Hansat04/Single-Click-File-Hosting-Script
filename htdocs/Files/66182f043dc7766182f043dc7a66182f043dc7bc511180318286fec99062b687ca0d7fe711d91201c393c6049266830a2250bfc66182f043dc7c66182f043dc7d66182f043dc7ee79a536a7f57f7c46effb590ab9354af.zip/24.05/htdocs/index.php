<!DOCTYPE>
<html>
<head>
	<title>title</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>

<body>
<header> 
<p><div class="container">
    <div><img class="bildl" src="bilder/kochmuetze.png" alt="" /></div>
    <div class="text"><h1>yum!yum!</h1></div>
	<div><img class="bildl" src="bilder/kochmuetze.png" alt="" /></div>
	</div>
	</p>
    </header>
	
	
<nav><a href="#">Home</a><a href="#">Vorspeise</a><a href="#">Hauptspeise</a><a href="#">Nachspeise</a><a href="#">Getränke</a></nav>
<main>
<div class="containermain">
<figure><div ><a href="#"><img class="abs" src="bilder/vorspeisen.jpg" alt="" /></a></div><figcaption>Vorspeise</figcaption></figure>
<figure><div ><a href="#"><img class="abs" src="bilder/nachspeisen.jpg" alt="" /></a></div><figcaption>Nachspeise</figure>
<figure><div ><a href="#"><img class="abs" src="bilder/hauptspeisen.jpg" alt="" /></a></div><figcaption>Hauptspeise</figure>
<figure><div ><a href="#"><img class="abs" src="bilder/getraenke.jpg" alt="" /></a></div><figcaption>Getränke</figure>
</div>
</main>
<footer><div class="asf">© 1998-2022 Yum! Yum! GmbH<div></footer>

</body>
<styles>
</styles>
</html>
